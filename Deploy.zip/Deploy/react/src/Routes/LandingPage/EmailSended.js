import React from "react";
import "css/landingPage/contact.scss";
import "css/global/variables.css";

const EmailSended = () => {
  return (
    <div className="contact-container">
      <h2>Your new password has been sent to your email address!</h2>
    </div>
  );
};

export default EmailSended;
